#!/bin/bash
git add .
git commit -m "Otomatik commit: $(date)"
git push origin main
